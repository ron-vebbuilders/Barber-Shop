<!DOCTYPE html>
<html>
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name='keywords' content='your, tags'>
  <meta name='description' content='150 words'>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="shortcut icon" type="image/png" href="images/logo.png">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
  <link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
  <link rel="stylesheet" type="text/css" href="css/animate.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
  <div class="wrapper">
    <header>
      <div class="container">
        <nav class="navigation">
          <div class="row">
            <div class="col-6 col-sm-6 col-md-4 col-lg-3">
              <div class="nav-header">
                <a class="nav-brand" href="index">
                  <img src="images/logo.png">
                </a>
              </div>
            </div>
            <div class="col-6 col-sm-6 col-md-8 col-lg-9">
              <div class="nav-toggle"></div>
              <div class="nav-menus-wrapper">
                <ul class="nav-menu clearfix">
                  <li class="active"><a href="index">Home</a></li>
                  <li><a href="about">About</a></li>
                  <li><a href="product">Product</a></li>
                </ul>
                <div class="clearfix"></div>
              </div>
            </div>
          </div>
        </nav>
      </div>
    </header>