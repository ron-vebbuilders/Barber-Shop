<footer>
<div class="container">
<div class="joine-us">
<h3>Joine with us</h3>
<div class="sosial">
<ul class="clearfix">
  <li><a href="#"><i class="fa fa-facebook"></i>  Facebook</a></li>
  <li><a href="#"><i class="fa fa-instagram"></i>  Instagram</a></li>
</ul>
</div>
</div>
</div>
</footer>
<!-- <div class="appointment-book">
<h4>Book An Appointment</h4>
<a href="#">Book Now</a>
<span class="close-app"><i class="fa fa-times"></i></span>
</div> -->
  </div>  
  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/menu.js"></script>
  <script src="js/wow.js"></script>
  <script src="js/custom.js"></script>

<script type="text/javascript">
  $(".close-app").click(function(event) {
    $(".appointment-book").fadeOut();
  });
</script>

</body>
</html>