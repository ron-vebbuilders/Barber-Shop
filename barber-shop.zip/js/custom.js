
$(document).ready(function() {
 $(".navigation").navigation({
  responsive:true,
  mobileBreakpoint:768,
  showDuration:300,
  hideDuration:300,
  showDelayDuration:100,
  hideDelayDuration:0,
  submenuTrigger:"hover",
  effect:"fade",
  submenuIndicator:true,
  hideSubWhenGoOut:true,
  visibleSubmenusOnMobile:false,
  fixed:false,
  overlay:true,
  overlayColor:"rgba(0, 0, 0, 0.5)",
  hidden:false,
  offCanvasSide:"left",
}); 
});


$('.client-logo-slider').owlCarousel({
  loop:true,
  margin:0,
  nav:false,
  items:6,
  dots: false,
  autoplay:true,
  autoplayTimeout:4000,
   responsive:{
        0:{
            items:2,
        },
        480:{
            items:3,
        },
        768:{
            items:4,
        },
        1200:{
            items:6,
        }
    }
});

$('.recipes-slider').owlCarousel({
  loop:true,
  margin:30,
  items:3,
  autoplay:true,
  nav:true,
  dots: true,
  autoplayTimeout:4000,
  responsive:{
        0:{
            items:1,
            nav:false,
        },
        480:{
            items:2,
            nav:false,
        },
        768:{
            items:3,
            nav:false,
        },
        1024:{
            nav:true,
        }
    }
});

new WOW().init();


$(window).scroll(function () {
  if ($(window).scrollTop() > 150) {
      $("header").addClass("fixed");
  } else {
      $("header").removeClass("fixed");
  }
});

